import 'dart:io';

import 'package:CaptainSayedApp/dimensions.dart';
import 'package:CaptainSayedApp/providers/app_data.dart';
import 'package:CaptainSayedApp/providers/bloc/bloc.dart';
import 'package:CaptainSayedApp/providers/program_progress.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/repos/progress_fun.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/upload_image_screen.dart';
import 'package:CaptainSayedApp/screens/day_exercises_screen/day_exercises_screen.dart';
import 'package:CaptainSayedApp/screens/day_exercises_screen/details_for_exercise_in_program.dart';
import 'package:CaptainSayedApp/screens/day_exercises_screen/program_rest_between_round.dart';
import 'package:CaptainSayedApp/screens/day_exercises_screen/program_timer_screen.dart';
import 'package:CaptainSayedApp/screens/exercise_details_screen/exercise_details_screen22.dart';
import 'package:CaptainSayedApp/screens/exercise_screen/exercise_screen.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/goals_screen.dart';
import 'package:CaptainSayedApp/screens/finesh_workout_screen.dart';
import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/screens/login_screen.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/premium_acc_screen.dart';
import 'package:CaptainSayedApp/screens/profile_screen/profile_screen.dart';
import 'package:CaptainSayedApp/screens/program_screen/program_Screen.dart';
import 'package:CaptainSayedApp/screens/reset_password.dart';
import 'package:CaptainSayedApp/screens/rest_between_round_screen/rest_between_round_screen.dart';
import 'package:CaptainSayedApp/screens/settings_screen/settings_screen.dart';
import 'package:CaptainSayedApp/screens/sign_up_screen.dart';
import 'package:CaptainSayedApp/screens/splash_screens/splash_screen0.dart';
import 'package:CaptainSayedApp/screens/splash_screens/splash_screens_layout.dart';
import 'package:CaptainSayedApp/screens/timer_screen/timer_screen.dart';

import 'package:CaptainSayedApp/services/auth.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/gender_screen.dart';
import 'package:CaptainSayedApp/widgets/layout_of_all_first_screens.dart';
import 'package:CaptainSayedApp/screens/welcome_screen.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/height_screen.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/level_screen.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:page_transition/page_transition.dart';
import 'package:provider/provider.dart';
import 'package:wakelock/wakelock.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
  static const initializationSettingsAndroid =
      AndroidInitializationSettings('ic_stat_get_fit');
  static const initializationSettingsIOS = IOSInitializationSettings(
    requestSoundPermission: false,
    requestBadgePermission: false,
    requestAlertPermission: false,
    // onDidReceiveLocalNotification: (_,__,___,____){},
  );
  final InitializationSettings initializationSettings = InitializationSettings(
    android: initializationSettingsAndroid,
    iOS: initializationSettingsIOS,
    // macOS: initializationSettingsMacOS,
  );

  static const AndroidNotificationDetails androidPlatformChannelSpecifics =
      AndroidNotificationDetails(
    'repeating channel id',
    'repeating channel name',
    'repeating description',
    color: Color(0xFFEE6F57),
    channelShowBadge: true,
    playSound: true,
    priority: Priority.max,
    importance: Importance.max,
    // sound: RawResourceAndroidNotificationSound()
  );
  static const NotificationDetails platformChannelSpecifics =
      NotificationDetails(android: androidPlatformChannelSpecifics);

  var _isFirstTimeToCheckAuthState = true;

  @override
  void initState() {
    Future.delayed(Duration.zero).then((_) async {
      await flutterLocalNotificationsPlugin.initialize(
        initializationSettings,
        onSelectNotification: (_) {
          Navigator.pushNamed(context, "/");
          return;
        },
      );
      await flutterLocalNotificationsPlugin.periodicallyShow(
        1,
        'Get Fit',
        'Come and Practice',
        RepeatInterval.weekly,
        platformChannelSpecifics,
        androidAllowWhileIdle: true,
      );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    Wakelock.enable();
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
    ]);
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => Auth()),

        ChangeNotifierProvider<UserData>(create: (_) => UserData()),
        ChangeNotifierProvider<AppData>(
          create: (_) => AppData(),
        ),

        ChangeNotifierProvider(
          create: (_) => Prog(),
        ),
        ChangeNotifierProvider<ProgramProgress>(
            create: (_) => ProgramProgress())
        // Provider(
        //   create: (_) => Bloc(),
        // )
      ],
      child: MaterialApp(
        title: 'Get Fit',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          unselectedWidgetColor: Colors.white,
          sliderTheme: SliderThemeData(
            thumbColor: Color(0xFFEE6F57),
            activeTrackColor: Color(0xFFEE6F57),
            inactiveTrackColor: Color(0xFFEE6F57).withOpacity(.3),
          ),
          textTheme: TextTheme(
            headline2: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
          primaryColor: Color(0xFFEE6F57),
          accentColor: Color(0xFFEE6F57),
          fontFamily: "Segoe UI",
        ),
        home: Consumer<Auth>(builder: (context, auth, __) {
          SizeConfig().init(context);
          Dimensions().init(context);
          final userData = Provider.of<UserData>(context, listen: false);
          return FutureBuilder(
              future: userData.prepareAllUserDataAtAppLaunch(),
              builder: (_, snap) {
                if (snap.connectionState == ConnectionState.waiting)
                  return Splash0(isJustWatingForStreamBuilder: true);
                else if (userData.userToken != null &&
                    userData.userToken.length != 0) {
                  if (_isFirstTimeToCheckAuthState) {
                    _isFirstTimeToCheckAuthState = false;
//  print("fdfdk0000000000000000000000000j");
//   print(userData.userToken);
                    return MySplash(isLogedIn: true);
                  } else {
                    print("fdfdkj");
                    print(userData.userToken);
                    return PremiumAccScreen();
                  }
                } else if (_isFirstTimeToCheckAuthState) {
                  _isFirstTimeToCheckAuthState = false;
                  //  print("fdf111111111111111111111111111dkj");
                  return MySplash(isLogedIn: false);
                } else {
                  //  print("fdf222222222222222222222222222222dkj");
                  return WelcomeScreen();
                }
              });
        }),
        routes: {
          GenderScreen.screenName: (_) =>
              LayoutOfAllFirstScreens(GenderScreen()),
          LevelScreen.screenName: (_) => LayoutOfAllFirstScreens(LevelScreen()),
          HeightScreen.screenName: (_) =>
              LayoutOfAllFirstScreens(HeightScreen()),
          UploadImageScreen.screenName: (_) =>
              LayoutOfAllFirstScreens(UploadImageScreen()),
          GoalsScreen.screenName: (_) => LayoutOfAllFirstScreens(GoalsScreen()),
          LoginScreen.screenName: (_) => Provider(
                create: (_) => Bloc(),
                child: LayoutOfAllFirstScreens(LoginScreen()),
              ),
          ResetPasswordScreen.screenName: (_) => Provider(
                create: (_) => Bloc(),
                child: LayoutOfAllFirstScreens(ResetPasswordScreen()),
              ),
          SignUpScreen.screenName: (_) => Provider(
                create: (_) => Bloc(),
                child: LayoutOfAllFirstScreens(SignUpScreen()),
              ),
          //HomeScreen.screenName: (_) => HomeScreen(),
          ExerciseScreen.screenName: (_) => ExerciseScreen(),
          TimerScreen.screenName: (_) => TimerScreen(),
          ExerciseDetailsScreen.screenName: (_) => ExerciseDetailsScreen(),
          ProfileScreen.screenName: (_) => ProfileScreen(),
          SettingScreen.screenName: (_) => SettingScreen(),
          ProgramScreen.screenName: (_) => ProgramScreen(),
          RestBetweenRoundsScreen.screenName: (_) => RestBetweenRoundsScreen(),
          FineshWorkoutScreen.screenName: (_) => FineshWorkoutScreen(),
          DayExercisesScreen.screenName: (_) => DayExercisesScreen(),
          DetailsForExerciseInDayScreen.screenName: (_) =>
              DetailsForExerciseInDayScreen(),
          ProgramTimerScreen.screenName: (_) => ProgramTimerScreen(),
          ProgramRestBetweenRoundsScreen.screenName: (_) =>
              ProgramRestBetweenRoundsScreen(),
          // Splash0.screenName: (_) => Splash0()
        },
      ),
    );
  }
}

class MySplash extends StatelessWidget {
  final bool isLogedIn;

  const MySplash({@required this.isLogedIn});

  @override
  Widget build(BuildContext context) {
    SizeConfig().init(context);
    return Splash0(
      isJustWatingForStreamBuilder: false,
      wilNavigateToHome: isLogedIn,
    );
  }
}
