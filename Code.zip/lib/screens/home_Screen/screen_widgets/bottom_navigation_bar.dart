import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/screens/message_screen/message.dart';
import 'package:CaptainSayedApp/screens/profile_screen/profile_screen.dart';
import 'package:CaptainSayedApp/screens/settings_screen/settings_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class BottomNavigationToolBar extends StatefulWidget {
  @override
  _BottomNavigationToolBarState createState() =>
      _BottomNavigationToolBarState();
}

class _BottomNavigationToolBarState extends State<BottomNavigationToolBar> {
  int navigationBarIndex = 0;

  @override
  Widget build(BuildContext context) {
    return BottomNavigationBar(
      items: [
        BottomNavigationBarItem(
          icon: Icon(AppIcon.home1111111111111),
          title: Container(),
        ),
        BottomNavigationBarItem(
          icon: Icon(AppIcon.message1111111111111111111),
          title: Container(),
        ),
        BottomNavigationBarItem(
          icon: Icon(AppIcon.user_11111111111),
          title: Container(),
        ),
        BottomNavigationBarItem(
          icon: Icon(AppIcon.bell11111111),
          title: Container(),
        ),
        BottomNavigationBarItem(
          icon: Icon(AppIcon.gear111111111),
          title: Container(),
        ),
      ],
      currentIndex: navigationBarIndex,
      selectedItemColor: Theme.of(context).primaryColor,
      unselectedItemColor: Colors.black,
      type: BottomNavigationBarType.fixed,
      onTap: (index) async {
        if (index == 2) {
          setState(() {
            navigationBarIndex = index;
          });
          await Future.delayed(Duration(milliseconds: 200));

          Navigator.of(context).pushNamed(ProfileScreen.screenName);
          setState(() {
            navigationBarIndex = 0;
          });
        } else if (index == 1) {
          setState(() {
            navigationBarIndex = index;
          });
          await Future.delayed(Duration(milliseconds: 200));

          Navigator.of(context)
              .push(MaterialPageRoute(builder: (_) => MessageScreen()));
          setState(() {
            navigationBarIndex = 0;
          });
        } else if (index == 4) {
          setState(() {
            navigationBarIndex = index;
          });
          await Future.delayed(Duration(milliseconds: 200));

          Navigator.of(context).pushNamed(SettingScreen.screenName);
          setState(() {
            navigationBarIndex = 0;
          });
        }
      },
    );
  }
}
