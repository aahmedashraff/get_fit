import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/upload_image_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/level_screen.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class HeightScreen extends StatefulWidget {
  static const screenName = "/height-screen";

  @override
  _HeightScreenState createState() => _HeightScreenState();
}

class _HeightScreenState extends State<HeightScreen> {
  var userHeight = 170;
  var userWeight = 80;
  var _heightExpanded = false;
  var _weightExpanded = false;
  @override
  

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Spacer(flex: 2),
        Align(
          alignment: Alignment.center,
          child: Text(
            "Mass",
            style: Theme.of(context).textTheme.headline2.copyWith(
                  fontSize: SizeConfig.safeBlockVertical * 5,
                ),
          ),
        ),
        Spacer(flex: 6),
        createHaightOrWeightSection(true),
        Spacer(),
        createHaightOrWeightSection(false),
        Spacer(flex: 6),
        GestureDetector(
          onTap: () {
            setState(() {
              _weightExpanded = false;
              _heightExpanded = false;
            });
            Provider.of<UserData>(context, listen: false)
                .setUserWeight(userWeight);

            Navigator.of(context).pushNamed(UploadImageScreen.screenName);
          },
          child: NextOrSubmitButton("Next"),
        ),
      ],
    );
  }

  Widget createHaightOrWeightSection(bool isHeight) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          isHeight ? "Height" : "Weight",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(fontSize: SizeConfig.safeBlockVertical * 2.5),
        ),
        SizedBox(
          height: SizeConfig.safeBlockVertical * 2.8,
        ),
        LayoutBuilder(
          builder: (_, constraints) => Container(
            child: Column(children: [
              GestureDetector(
                onTap: () {
                  if (isHeight) {
                    setState(() {
                      _heightExpanded = !_heightExpanded;
                      _weightExpanded = false;
                    });
                  } else {
                    setState(() {
                      _weightExpanded = !_weightExpanded;
                      _heightExpanded = false;
                    });
                  }
                },
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        isHeight ? "Cm" : "Kg",
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: SizeConfig.safeBlockHorizontal * 3.5,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                     Text(
                      isHeight ? "$userHeight" : "$userWeight",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: SizeConfig.safeBlockHorizontal * 4.2,
                      ),
                    ),
                    Icon(
                      (isHeight && _heightExpanded) ||
                              (!isHeight && _weightExpanded)
                          ? Icons.expand_less
                          : Icons.expand_more,
                      size: (SizeConfig.safeBlockHorizontal +
                              SizeConfig.safeBlockVertical) *
                          4.5 /
                          2,
                    ),
                  ],
                ),
              ),
              if (_heightExpanded && isHeight)
                Slider(
                  value: userHeight.toDouble(),
                  min: 120,
                  max: 220,
                  onChanged: (value) {
                    setState(() {
                      userHeight = value.toInt();
                    });
                  },
                  divisions: 100,
                ),
              if (_weightExpanded && !isHeight)
                Slider(
                  value: userWeight.toDouble(),
                  min: 50,
                  max: 200,
                  onChanged: (value) {
                    setState(() {
                      userWeight = value.toInt();
                    });
                  },
                  divisions: 150,
                )
            ]),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius:
                  BorderRadius.circular(SizeConfig.safeBlockHorizontal * 2),
            ),
            padding: EdgeInsets.symmetric(
              horizontal: SizeConfig.safeBlockHorizontal * 4.5,
              vertical: SizeConfig.safeBlockVertical * 1.3,
            ),
            width: constraints.maxWidth,
          ),
        ),
      ],
    );
  }
}
