import 'package:CaptainSayedApp/screens/sign_up_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:CaptainSayedApp/widgets/radio_button_container.dart';
import 'package:CaptainSayedApp/widgets/selectable_recatangle.dart';
import 'package:flutter/material.dart';

class GoalsScreen extends StatelessWidget {
  static const screenName = "/goals";
  static const titles = <String>[
    "Build Strength",
    "Build Muscle",
    "Lose Fat",
    "Learn Skills"
  ];
  static const subtitles = <String>[
    "Get stronger and perform exercises with greater ease",
    "increase volume and difficulty to ensure muscle growth",
    "Optimized for high intensity fat burning workouts",
    "Like arm balancing and more advanced movements like Front lever and Human flag"
  ];
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Spacer(flex: 4),
        Text(
          "Goals",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(fontSize: SizeConfig.safeBlockVertical * 4.5),
        ),
        Spacer(flex: 6),
        RadioButtonContainer(
          title: titles[0],
          subtitle: subtitles[0],
          isFromLevelScreen: false,
        ),
        Spacer(flex: 2),
        RadioButtonContainer(
          title: titles[1],
          subtitle: subtitles[1],
          isFromLevelScreen: false,
        ),
        Spacer(flex: 2),
        RadioButtonContainer(
          title: titles[2],
          subtitle: subtitles[2],
          isFromLevelScreen: false,
        ),
        Spacer(flex: 2),
        RadioButtonContainer(
          title: titles[3],
          subtitle: subtitles[3],
          isFromLevelScreen: false,
        ),
        Spacer(flex: 4),
        GestureDetector(
          onTap: () => Navigator.of(context).pushNamed(SignUpScreen.screenName),
          child: NextOrSubmitButton("Next"),
        )
      ],
    );
  }
}
