
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/widgets/create_gender_box.dart';
import 'package:CaptainSayedApp/screens/before_signup_screens/height_screen.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:flutter/material.dart';

class GenderScreen extends StatelessWidget {
  static const screenName = "/gender-screen";
  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Spacer(flex: 2),
        Text(
          "Gender",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(fontSize: SizeConfig.safeBlockVertical*5),
        ),
        Spacer(flex: 3),
        CreateGenderBox(male: true),
        Spacer(flex:3),
        CreateGenderBox(male: false),
        Spacer(flex: 3),
        GestureDetector(
          onTap: () =>Navigator.of(context).pushNamed(HeightScreen.screenName),
          child: NextOrSubmitButton("Next"),
        ),
      ],
    );
  }
}
