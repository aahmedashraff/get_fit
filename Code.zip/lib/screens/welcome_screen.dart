import 'package:CaptainSayedApp/screens/before_signup_screens/gender_screen.dart';
import 'package:CaptainSayedApp/screens/home_Screen/home_screen.dart';
import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/screens/login_screen.dart';
import 'package:CaptainSayedApp/services/auth.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/premium_acc_screen.dart';

class WelcomeScreen extends StatelessWidget {
  static const screenName = "/welcome";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            "assets/images/0.jpg",
            width: SizeConfig.screenWidth,
            height: SizeConfig.screenHeight,
            fit: BoxFit.cover,
          ),
          Container(
            color: Color.fromRGBO(0, 0, 0, .45),
          ),
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.safeBlockHorizontal * 100,
            child: SingleChildScrollView(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                crossAxisAlignment: CrossAxisAlignment.center,
                //mainAxisSize: MainAxisSize.max,
                children: [
                  SizedBox(
                    height: SizeConfig.safeBlockVertical * 48,
                  ),
                  Text(
                    "ARE YOU READY FOR",
                    style: TextStyle(
                      fontSize: SizeConfig.safeBlockHorizontal * 4.2,
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(
                    height: SizeConfig.safeBlockVertical * 1.5,
                  ),
                  RichText(
                    text: TextSpan(
                      text: "SUPERHUMAN",
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontSize: SizeConfig.safeBlockHorizontal * 7.5,
                        fontWeight: FontWeight.bold,
                      ),
                      children: [
                        TextSpan(
                          text: " STRENGTH",
                          style: Theme.of(context).textTheme.headline2.copyWith(
                                fontSize: SizeConfig.safeBlockHorizontal * 7.5,
                              ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical * 7),
                  createButton(
                    gmail: false,
                    facebook: false,
                    text: "Log In",
                    context: context,
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical * 3),
                  createButton(
                    gmail: false,
                    facebook: true,
                    text: "SIGN IN WITH FACEBOOK",
                    context: context,
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical * 3),
                  createButton(
                    gmail: true,
                    facebook: false,
                    text: "SIGN IN WITH GOOGLE",
                    context: context,
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical * 1.9),
                  Container(
                    child: Padding(
                      padding: EdgeInsets.symmetric(
                        horizontal: SizeConfig.safeBlockHorizontal * 9,
                      ),
                      child: FittedBox(
                        child: Row(
                          children: [
                            Text(
                              "You Do Not Have An Account? ",
                              style: TextStyle(
                                color: Colors.white,
                                fontSize: SizeConfig.safeBlockHorizontal * 3.8,
                              ),
                            ),
                            GestureDetector(
                              onTap: () => Navigator.of(context)
                                  .pushNamed(GenderScreen.screenName),
                              child: Text(
                                "Sign Up",
                                style: TextStyle(
                                  color: Theme.of(context).primaryColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: SizeConfig.safeBlockHorizontal * 5,
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          Positioned(
            child: Image.asset(
              "assets/images/logo.png",
              width: SizeConfig.safeBlockHorizontal * 15,
            ),
            top: MediaQuery.of(context).padding.top+SizeConfig.safeBlockVertical,
            left: SizeConfig.safeBlockHorizontal*3,
          )
        ],
      ),
    );
  }

  Widget createButton({
    @required bool gmail,
    @required bool facebook,
    @required String text,
    @required BuildContext context,
  }) {
    return GestureDetector(
      onTap: !gmail && !facebook
          ? () => Navigator.of(context).pushNamed(LoginScreen.screenName)
          : (gmail
              ? () async {
                  try {
                    await Auth().googleSignIn(context: context);
                  } on Exception catch (e) {
                    return;
                  }
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => PremiumAccScreen()),
                      (_) => false);
                }
              : () async {
                  try {
                    await Auth().facebookSignIn(context);
                  } on Exception catch (e) {
                    return;
                  }
                  Navigator.of(context).pushAndRemoveUntil(
                      MaterialPageRoute(builder: (_) => PremiumAccScreen()),
                      (_) => false);
                }),
      child: Container(
        child: Row(
          mainAxisAlignment: facebook || gmail
              ? MainAxisAlignment.start
              : MainAxisAlignment.center,
          children: [
            if (gmail || facebook)
              Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: SizeConfig.safeBlockHorizontal * 4,
                ),
                child: Image.asset(
                  gmail
                      ? "assets/images/gmail.png"
                      : "assets/images/Facebook.png",
                  width: SizeConfig.safeBlockHorizontal * 8,
                  height: SizeConfig.safeBlockHorizontal * 6,
                ),
              ),
            Flexible(
              child: Text(
                text,
                style: TextStyle(
                  color: Colors.black,
                  fontWeight: FontWeight.bold,
                  fontSize: SizeConfig.safeBlockHorizontal * 3.7,
                ),
                softWrap: true,
              ),
            ),
          ],
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(
            SizeConfig.safeBlockHorizontal * 2.5,
          ),
          color: gmail || facebook ? Colors.white : null,
          gradient: gmail || facebook
              ? null
              : LinearGradient(
                  colors: [Color(0xFF77382C), Theme.of(context).primaryColor],
                  begin: Alignment.centerLeft,
                  end: Alignment.centerRight,
                ),
        ),
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.safeBlockVertical * 2.5,
        ),
        margin: EdgeInsets.symmetric(
            horizontal: SizeConfig.safeBlockHorizontal * 9),
      ),
    );
  }
}
