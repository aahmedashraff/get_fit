import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/widgets/paragraph.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class PremiumAccScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Column(
          children: [
            Stack(
              children: [
                ClipRRect(
                  child: Image.asset(
                    "assets/images/Fat.jpg",
                    width: double.infinity,
                    height: SizeConfig.safeBlockVertical * 25,
                    fit: BoxFit.cover,
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft:
                        Radius.circular(SizeConfig.safeBlockHorizontal * 3),
                    bottomRight:
                        Radius.circular(SizeConfig.safeBlockHorizontal * 3),
                  ),
                ),
                Positioned.fill(
                  child: Container(
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(.6),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(
                          SizeConfig.safeBlockHorizontal * 3,
                        ),
                        bottomRight: Radius.circular(
                          SizeConfig.safeBlockHorizontal * 3,
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned.fill(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text(
                        "Get Ready For",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: SizeConfig.safeBlockHorizontal * 5,
                        ),
                      ),
                      Text(
                        "Premium Account",
                        style: TextStyle(
                            color: Theme.of(context).primaryColor,
                            fontSize: SizeConfig.safeBlockHorizontal * 7,
                            fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                )
              ],
            ),
            Spacer(),
            Paragraph(),
            Spacer(),
            RaisedButton(
              onPressed: () => Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (_) => HomeScreen())),
              child: Text(
                "skip",
                style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: SizeConfig.safeBlockHorizontal * 4),
              ),
              color: Theme.of(context).primaryColor,
              shape: RoundedRectangleBorder(
                borderRadius:
                    BorderRadius.circular(SizeConfig.safeBlockHorizontal * 2),
              ),
              padding: EdgeInsets.symmetric(
                horizontal: SizeConfig.safeBlockHorizontal * 33,
                vertical: SizeConfig.safeBlockVertical * 1.5,
              ),
            )
          ],
        ),
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).padding.bottom +
              SizeConfig.safeBlockVertical,
        ),
        height: SizeConfig.screenHeight,
      ),
      backgroundColor: Color(0xFFE9E9E9),
    );
  }
}
