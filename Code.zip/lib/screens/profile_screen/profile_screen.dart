import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/before_after_sec.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/bottom_container_content.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/screen_head.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/top_container_content.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/user_info_container.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/user_photo.dart';
import 'package:CaptainSayedApp/screens/settings_screen/settings_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatelessWidget {
  static const screenName = "/profile-screen";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Stack(children: [
          Container(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  ScreenHead(),
                  UserPhot(false),
                  SizedBox(height: SizeConfig.safeBlockVertical),
                  UserInfoContainer(),
                  SizedBox(height: SizeConfig.safeBlockVertical),
                  Icon(
                    AppIcon.placeholder,
                    color: Colors.white,
                    size: SizeConfig.safeBlockVertical * 2,
                  ),
                  //Spacer(flex: 3),
                  Consumer<UserData>(
                    builder: (_, data, ch) => Text(
                      data.userCountry,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: SizeConfig.safeBlockVertical * 1.2,
                      ),
                    ),
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical),
                  InkWell(
                    child: Container(
                      child: Text(
                        "Edit Profile",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                            fontSize: SizeConfig.blockSizeVertical * 1.3),
                      ),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(
                            SizeConfig.safeBlockHorizontal),
                      ),
                      padding: EdgeInsets.symmetric(
                        vertical: SizeConfig.safeBlockVertical * .6,
                      ),
                      width: SizeConfig.safeBlockHorizontal*93,
                    ),
                    onTap: () => Navigator.of(context)
                        .pushNamed(SettingScreen.screenName),
                  ),
                 SizedBox(height: SizeConfig.safeBlockVertical*2.5),
                 BeforeAfterSec(),
                  SizedBox(height: SizeConfig.safeBlockVertical*2.5),
                  Container(
                    child: BottomContainerContent(),
                    width: SizeConfig.safeBlockHorizontal * 100,
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.only(
                        topLeft:
                            Radius.circular(SizeConfig.safeBlockHorizontal * 4),
                        topRight:
                            Radius.circular(SizeConfig.safeBlockHorizontal * 4),
                      ),
                    ),
                    padding:
                        EdgeInsets.only(top: SizeConfig.screenHeight * 1 / 100),
                    height: SizeConfig.screenHeight * 65 / 100,
                  )
                ],
              ),
            ),
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            //padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [Color(0xFF77382C), Theme.of(context).primaryColor],
                begin: Alignment.bottomCenter,
                end: Alignment.topCenter,
              ),
            ),
          ),
          //ScreenHead(),
        ]),
        backgroundColor: Color(0xFFE9E9E9));
  }
}
