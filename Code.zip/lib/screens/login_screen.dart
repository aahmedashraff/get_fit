import 'package:CaptainSayedApp/providers/bloc/bloc.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/screens/home_Screen/home_screen.dart';
import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/screens/reset_password.dart';
import 'package:CaptainSayedApp/services/auth.dart';
import 'package:CaptainSayedApp/services/show_auth_error_message.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/widgets/create_text_input11.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/premium_acc_screen.dart';

class LoginScreen extends StatefulWidget {
  static const screenName = "/login-screen";

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  var _isSubmitClicked = false;
  var _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final bloc = Provider.of<Bloc>(context);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Spacer(flex: 20),
        Text(
          "Login",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(fontSize: SizeConfig.safeBlockHorizontal * 9),
        ),
        Spacer(flex: 8),
        StreamBuilder<String>(
          stream: bloc.signInEmail,
          builder: (_, snap) => CreateTextInput(
            label: "Email",
            snapShot: snap,
            isSubmitButtonClicked: _isSubmitClicked,
            updateStreamFunction: bloc.updateSignInEmail,
          ),
        ),
        Spacer(flex: 1),
        StreamBuilder<String>(
          stream: bloc.signInPass,
          builder: (_, snap) => CreateTextInput(
            label: "Password",
            snapShot: snap,
            isSubmitButtonClicked: _isSubmitClicked,
            updateStreamFunction: bloc.updateSignInPass,
            isPassword: true,
          ),
        ),
        Spacer(flex: 20),
        StreamBuilder<Object>(
            stream: bloc.validateSubmitionForLogIn,
            builder: (context, snapshot) {
              return GestureDetector(
                onTap: _isLoading
                    ? null
                    : snapshot.hasData
                        ? () => _submit(bloc)
                        : () {
                            if (!_isSubmitClicked) {
                              setState(() {
                                _isSubmitClicked = true;
                              });
                            }
                          },
                child: _isLoading
                    ? CircularProgressIndicator()
                    : NextOrSubmitButton("Login now"),
              );
            }),
        Spacer(flex: 1),
        GestureDetector(
          onTap: () =>
              Navigator.of(context).pushNamed(ResetPasswordScreen.screenName),
          child: Text(
            "Forgot your password?",
            style: TextStyle(
              color: Colors.white,
              fontSize: SizeConfig.safeBlockHorizontal * 4,
            ),
          ),
        ),
      ],
    );
  }

  // Future<void> _submit(Bloc bloc) async {
  //   FocusScope.of(context).unfocus();
  //   setState(() {
  //     _isLoading = true;
  //   });
  //   try {
  //     await Auth()
  //         .signInWithEmailAndPass(bloc.getSignInEmail, bloc.getSignInPass);
  //   } catch (e) {
  //     showErrorMessage(context: context, error: e.toString());
  //     setState(() {
  //       _isLoading = false;
  //     });
  //     return;
  //   }
  //   bloc.dispose();

  //   setState(() {
  //     _isLoading = false;
  //   });
  //   Navigator.of(context).pushAndRemoveUntil(
  //     MaterialPageRoute(builder: (_) => PremiumAccScreen()),
  //     (_) => false,
  //   );
  // }

  Future<void> _submit(Bloc bloc) async {
    FocusScope.of(context).unfocus();
    setState(() {
      _isLoading = true;
    });

    try {
      await Auth().signInWithEmailAndPass(
          email: bloc.getSignInEmail,
          pass: bloc.getSignInPass,
          context: context);
    } catch (e) {
      showDialogMessage(
          context: context,
          title: "An error occurred",
          message:
              "This email or password may be wrong, please check your connection and try again.");
      setState(() {
        _isLoading = false;
      });
      return;
    }
    // setState(() {
    //   _isLoading = false;
    // });
    // return;
    await Provider.of<UserData>(context, listen: false)
        .setUserEmail(bloc.getSignInEmail);
    bloc.dispose();
    setState(() {
      _isLoading = false;
    });
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => PremiumAccScreen()), (_) => false);
  }
}
