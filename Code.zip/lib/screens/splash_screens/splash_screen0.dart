// import 'dart:html';

import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/premium_acc_screen.dart';
import 'package:CaptainSayedApp/screens/splash_screens/splash_screens_layout.dart';
import 'package:CaptainSayedApp/screens/splash_screens/widgets/dots_progress_indicator.dart';
import 'package:CaptainSayedApp/screens/splash_screens/widgets/get_fit_text.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';
// import 'package:loading_indicator/loading_indicator.dart';

class Splash0 extends StatefulWidget {
  static const screenName = "/splash0";
  final bool isJustWatingForStreamBuilder;
  final bool wilNavigateToHome;

  const Splash0(
      {this.isJustWatingForStreamBuilder, this.wilNavigateToHome = false});

  @override
  _Splash0State createState() => _Splash0State();
}

class _Splash0State extends State<Splash0> {
  @override
  void initState() {
    if (!widget.isJustWatingForStreamBuilder)
      Future.delayed(Duration(seconds: 10), () {
        widget.wilNavigateToHome
            ? Navigator.of(context)
                .pushAndRemoveUntil(MaterialPageRoute(builder: (_) => PremiumAccScreen()),(_)=>false)
            : Navigator.of(context).pushAndRemoveUntil(PageTransition(
                child: SplashScreensLayout(0),
                type: PageTransitionType.rightToLeft),(_)=>false);
      });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Image.asset(
            "assets/images/Fat.jpg",
            width: SizeConfig.screenWidth,
            height: SizeConfig.screenHeight,
            fit: BoxFit.cover,
          ),
          Container(
            color: Color.fromRGBO(0, 0, 0, .45),
          ),
          Container(
            height: SizeConfig.screenHeight,
            width: SizeConfig.screenWidth,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                GetFitText(
                  isJustWatingForStreamBuilder:
                      widget.isJustWatingForStreamBuilder,
                ),
                SizedBox(height: SizeConfig.safeBlockVertical * 2),
                DotsProgressIndicator(),
                // SizedBox(height: SizeConfig.safeBlockVertical * .5),
                // Container(
                //   // decoration:
                //   //     BoxDecoration(border: Border.all(color: Colors.white)),
                //   width: SizeConfig.safeBlockHorizontal * 25,
                //   height: SizeConfig.safeBlockVertical * 1.5,
                //   child: LoadingIndicator(
                //     indicatorType: Indicator.ballBeat,
                //     color: Theme.of(context).primaryColor,
                //   ),
                // )
              ],
            ),
          )
        ],
      ),
    );
  }
}
