import 'package:CaptainSayedApp/screens/splash_screens/widgets/skip_button.dart';
import 'package:CaptainSayedApp/screens/splash_screens/widgets/small_vertical_line.dart';
import 'package:CaptainSayedApp/screens/welcome_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:page_transition/page_transition.dart';

class SplashScreensLayout extends StatelessWidget {
  final int splashIndex;
  SplashScreensLayout(this.splashIndex);
  @override
  Widget build(BuildContext context) {
    return WillPopScope(onWillPop: ()async=>splashIndex!=0,
          child: Scaffold(
        body: Stack(
          children: [
            Image.asset(
              splashData[splashIndex]["image"],
              width: SizeConfig.screenWidth,
              height: SizeConfig.screenHeight,
              fit: BoxFit.cover,
            ),
            Container(
              color: Color.fromRGBO(0, 0, 0, .45),
            ),
            SkipButton(
              onPress: () {
                splashIndex == 2
                    ? Navigator.of(context).push(
                        MaterialPageRoute(builder: (_) => WelcomeScreen()))
                    : Navigator.push(
                        context,
                        PageTransition(
                          type: PageTransitionType.rightToLeft,
                          child: SplashScreensLayout(splashIndex + 1),
                        ),
                        // ModalRoute.withName("/"),
                      );

                //
              },
            ),
            Positioned(
              child: Container(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SmallVerticalLine(),
                    SizedBox(width: SizeConfig.safeBlockHorizontal * 3),
                    Flexible(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            splashData[splashIndex]["title"],
                            style: TextStyle(
                              color: Theme.of(context).primaryColor,
                              fontSize: SizeConfig.safeBlockHorizontal * 6,
                              fontWeight: FontWeight.bold,
                              height: 1.0,
                            ),
                          ),
                          SizedBox(height: SizeConfig.safeBlockVertical * 2),
                          Text(
                            splashData[splashIndex]["subtitle"],
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: SizeConfig.safeBlockHorizontal * 4.5,
                            ),
                          )
                        ],
                      ),
                    )
                  ],
                ),
                width: SizeConfig.safeBlockHorizontal * 90,
              ),
              bottom: SizeConfig.safeBlockVertical * 5,
              left: SizeConfig.safeBlockHorizontal * 3,
            )
          ],
        ),
      ),
    );
  }

  static const splashData = <Map<String, String>>[
    {
      "image": "assets/images/splash1.jpg",
      "title": "You have to bear",
      "subtitle":
          "Refine Your Body In The Fastest Time With The Best Exercises That Work To Give You An Attractive Body In A Short Time.",
    },
    {
      "image": "assets/images/splash2.jpg",
      "title": "Challenge yourself",
      "subtitle":
          "Be Ready With Us In Training To Get What You Want. Nothing Comes Without The Fatigue Of Challenging Yourself.",
    },
    {
      "image": "assets/images/splash3.jpg",
      "title": "Be helpful to others",
      "subtitle":
          "Remember When You Are Helping Others You Are Benefiting Yourself Before Others You Should Seek Help.",
    }
  ];
}
