import 'package:CaptainSayedApp/providers/bloc/bloc.dart';
import 'package:CaptainSayedApp/services/auth.dart';
import 'package:CaptainSayedApp/services/show_auth_error_message.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/widgets/create_text_input11.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ResetPasswordScreen extends StatefulWidget {
  static const screenName = "reset-password";

  @override
  _ResetPasswordScreenState createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  var _isSubmitClicked = false;
  var _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final bloc = Provider.of<Bloc>(context);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Spacer(flex: 2),
        Text(
          "Reset Password",
          style: Theme.of(context)
              .textTheme
              .headline2
              .copyWith(fontSize: SizeConfig.safeBlockHorizontal * 9),
        ),
        Spacer(),
        StreamBuilder<String>(
          stream: bloc.resetEmail,
          builder: (_, snap) => CreateTextInput(
            label: "Email",
            snapShot: snap,
            isSubmitButtonClicked: _isSubmitClicked,
            updateStreamFunction: bloc.updateResetPasswordEmail,
          ),
        ),
        Spacer(flex: 3),
        StreamBuilder<Object>(
            stream: bloc.resetEmail,
            builder: (context, snapshot) {
              return GestureDetector(
                onTap: _isLoading
                    ? null
                    : snapshot.hasData
                        ? () => _submit(bloc)
                        : () {
                            if (!_isSubmitClicked) {
                              setState(() {
                                _isSubmitClicked = true;
                              });
                            }
                          },
                child: _isLoading
                    ? CircularProgressIndicator()
                    : NextOrSubmitButton("Reset Password"),
              );
            }),
        SizedBox(height: SizeConfig.safeBlockVertical * 1),
      ],
    );
  }

  Future<void> _submit(Bloc bloc) async {
    FocusScope.of(context).unfocus();
    try {
      await Auth().restPassword(bloc.getResetPassEmail);
    } catch (e) {
      showDialogMessage(
        context: context,
        message:
            "This email may be not exist, please check your connetion and try again",
            title: "Error"
      );
      setState(() {
        _isLoading = false;
      });
      return;
    }
    showDialogMessage(
        context: context,
        message:
            "Message has been sent successfully",
            title: "Done"
      );
    bloc.disposeRestEmailStream();
    setState(() {
      _isLoading = false;
    });
  }
}
