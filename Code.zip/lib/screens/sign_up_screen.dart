import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/providers/bloc/bloc.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/screens/home_Screen/home_screen.dart';
import 'package:CaptainSayedApp/screens/home_screen2/home_screen.dart';
import 'package:CaptainSayedApp/services/auth.dart';
import 'package:CaptainSayedApp/services/show_auth_error_message.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:CaptainSayedApp/widgets/create_text_input11.dart';
import 'package:CaptainSayedApp/widgets/next_or_suubmit_button.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:CaptainSayedApp/screens/premium_acc_screen/premium_acc_screen.dart';

class SignUpScreen extends StatefulWidget {
  static const screenName = "sign-up";

  @override
  _SignUpScreenState createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  var _isSubmitedclicked = false;
  var _isLoading = false;
  @override
  Widget build(BuildContext context) {
    final bloc = Provider.of<Bloc>(context);
    return WillPopScope(
      onWillPop: () async {
        bloc.resetStreamsValue();
        FocusScope.of(context).unfocus();
        return true;
      },
      child: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Spacer(flex: 2),
            Text(
              "Sign Up",
              style: Theme.of(context)
                  .textTheme
                  .headline2
                  .copyWith(fontSize: SizeConfig.safeBlockVertical * 4.8),
            ),
            Spacer(flex: 8),
            StreamBuilder<String>(
              stream: bloc.userName,
              builder: (_, snap) => CreateTextInput(
                label: "User name",
                snapShot: snap,
                isSubmitButtonClicked: _isSubmitedclicked,
                updateStreamFunction: bloc.updateUserName,
              ),
            ),
            StreamBuilder<String>(
              stream: bloc.fullName,
              builder: (_, snap) => CreateTextInput(
                label: "Full name",
                snapShot: snap,
                isSubmitButtonClicked: _isSubmitedclicked,
                updateStreamFunction: bloc.updateFullName,
              ),
            ),
            StreamBuilder<String>(
              stream: bloc.email,
              builder: (_, snap) => CreateTextInput(
                label: "Email",
                snapShot: snap,
                isSubmitButtonClicked: _isSubmitedclicked,
                updateStreamFunction: bloc.updateEmail,
              ),
            ),
            StreamBuilder<String>(
              stream: bloc.password,
              builder: (_, snap) => CreateTextInput(
                label: "Password",
                snapShot: snap,
                isSubmitButtonClicked: _isSubmitedclicked,
                updateStreamFunction: bloc.updatePass,
                isPassword: true,
                showViewPasswordIcon: true,
              ),
            ),
            Spacer(flex: 5),
            //if (!_isLoading)
            StreamBuilder(
                stream: bloc.validateSubmitionForSignUp,
                builder: (context, snapshot) {
                  return GestureDetector(
                    onTap: _isLoading
                        ? null
                        : snapshot.hasData
                            ? () => _submit(bloc)
                            : () {
                                if (!_isSubmitedclicked) {
                                  setState(() {
                                    _isSubmitedclicked = true;
                                  });
                                }
                              },
                    child: _isLoading
                        ? CircularProgressIndicator()
                        : NextOrSubmitButton("Create Account"),
                  );
                }),
            //if (_isLoading) CircularProgressIndicator()
          ],
        ),
        height: SizeConfig.safeBlockVertical * 100 -
            MediaQuery.of(context).padding.top,
      ),
    );
  }

  Future<void> _submit(Bloc bloc) async {
    FocusScope.of(context).unfocus();
    setState(() {
      _isLoading = true;
    });

    try {
      await Auth().signUpwithEmailAndPass(
          email: bloc.getEmail,
          pass: bloc.getPass,
          fullName: bloc.getFullName,
          userData: Provider.of<UserData>(context, listen: false).getUserData,
          context: context);
    } catch (e) {
      showDialogMessage(
          context: context,
          title: "An error occurred",
          message:
              "This email may be already existed, please check your connection and try again.");
      setState(() {
        _isLoading = false;
      });
      return;
    }
    // setState(() {
    //   _isLoading = false;
    // });
    // return;
    await Provider.of<UserData>(context, listen: false).saveUserFullName(name: bloc.getFullName);
    await Provider.of<UserData>(context, listen: false)
        .setUserEmail(bloc.getEmail);
    bloc.dispose();
    setState(() {
      _isLoading = false;
    });
    Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => PremiumAccScreen()), (_) => false);
  }
}
