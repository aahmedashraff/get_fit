import 'package:CaptainSayedApp/screens/tabs_screen/widgets/create_tab.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class MyTabBar extends StatelessWidget {
  final TabController controller;

  const MyTabBar({this.controller}) ;
  @override
  Widget build(BuildContext context) {
    return Container(
      child: TabBar(
        controller: controller,
        tabs: [
          CreateTab(title: "FAVOURITES"),
          CreateTab(title: "MY LIST"),
          CreateTab(title: "DOWNLOADS")
        ],
        indicatorPadding: EdgeInsets.zero,
        indicatorColor: Colors.black,
        indicatorSize: TabBarIndicatorSize.label,
        labelPadding: EdgeInsets.zero,
        indicatorWeight: 4,
      ),
      width: SizeConfig.screenWidth,
      color: Theme.of(context).primaryColor,
      padding:
          EdgeInsets.symmetric(vertical: SizeConfig.safeBlockVertical * .5),
    );
  }
}
