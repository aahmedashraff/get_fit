import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class TopScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.symmetric(
          // vertical: MediaQuery.of(context).padding.top,
          horizontal: SizeConfig.safeBlockHorizontal * 4),
      child: Row(
        children: [
          IconButton(
            icon: Icon(AppIcon.back, color: Colors.black),
            onPressed: () => Navigator.of(context).pop(),
          ),
          Spacer(),
          Text(
            "My Library",
            style: TextStyle(
              color: Colors.black,
              fontWeight: FontWeight.bold,
              fontSize: SizeConfig.safeBlockHorizontal*4
            ),
          )
        ],
      ),
    );
  }
}
