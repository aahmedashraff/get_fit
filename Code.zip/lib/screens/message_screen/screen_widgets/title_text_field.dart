import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class TitleTextField extends StatelessWidget {
  final void Function(String title) getTextFieldValue;

  const TitleTextField({this.getTextFieldValue});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: TextField(
        onChanged:(value)=> getTextFieldValue(value),
        cursorColor: Theme.of(context).primaryColor,
        decoration: InputDecoration.collapsed(hintText: "Title"),
      ),
      padding: EdgeInsets.symmetric(
        horizontal: SizeConfig.safeBlockHorizontal * 3,
        vertical: SizeConfig.safeBlockVertical * 2,
      ),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(SizeConfig.safeBlockHorizontal * 2),
      ),
    );
  }
}
