import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class SocialAccountItem extends StatelessWidget {
  final String title;
  final Function onPress;

  const SocialAccountItem({
    this.title,
    this.onPress,
  });

  Future<void> _launchApp() async {
    String url = title == "Instagram"
        ? "https://www.instagram.com/sayed_hussien.fit/"
        : (title == "Facebook"
            ? "https://www.facebook.com/sayedhussien32/"
            : "https://www.youtube.com/channel/UCxg5X7NczVjUUMe-OWHFlrw");

    if (await canLaunch(url)) {
      await launch(url);
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _launchApp,
      child: Container(
        child: Row(
          children: [
            Spacer(),
            Image.asset(
              "assets/images/$title.png",
              width: SizeConfig.safeBlockVertical * 3.5,
              height: SizeConfig.safeBlockVertical * 3.5,
              fit: BoxFit.cover,
            ),
            Spacer(flex: 1),
             Text(title),
            Spacer(flex: 3),
          ],
        ),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius:
                BorderRadius.circular(SizeConfig.blockSizeHorizontal * 1.5),
            border: Border.all(
              color: Colors.grey,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(.3),
                blurRadius: 4,
                offset: Offset(
                  0,
                  SizeConfig.safeBlockVertical * .3,
                ),
              )
            ]),
        padding:
            EdgeInsets.symmetric(vertical: SizeConfig.blockSizeVertical * .5),
        margin: EdgeInsets.symmetric(
            horizontal: SizeConfig.safeBlockHorizontal * 27),
      ),
    );
  }
}
