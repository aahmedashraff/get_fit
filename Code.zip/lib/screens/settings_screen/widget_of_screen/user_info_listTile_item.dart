import 'package:CaptainSayedApp/screens/settings_screen/widget_of_screen/gender_info.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class UserInfoListTileItem extends StatelessWidget {
  final String title;
  final String subtitle;
  final Function onPress;

  const UserInfoListTileItem({
    @required this.title,
     this.subtitle,
    this.onPress,
  });
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.symmetric(horizontal: SizeConfig.safeBlockHorizontal * 5),
      child: ListTile(
        title: Text(
          title,
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        subtitle: subtitle==null?null: Text(
          subtitle,
          style: TextStyle(
            color: Colors.white,
            fontSize: SizeConfig.safeBlockHorizontal * 3,
          ),
        ),
        trailing: title == "Gender"
            ? GenderInfo()
            : const Text(
                "Edit",
                style: TextStyle(color: Colors.white),
              ),
        onTap: onPress,
        //dense: true,
        //visualDensity: VisualDensity(vertical: -4),
      ),
    );
  }
}
