import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/screens/profile_screen/screen_widgets/user_photo.dart';
import 'package:CaptainSayedApp/screens/settings_screen/widget_of_screen/content.dart';
import 'package:CaptainSayedApp/screens/settings_screen/widget_of_screen/social_account_item.dart';
import 'package:CaptainSayedApp/screens/settings_screen/widget_of_screen/top_of_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class SettingScreen extends StatelessWidget {
  static const screenName = "/setting-screen";
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
          child: SingleChildScrollView(
                      child: Column(
              children: [
      TopOfScreen(),
      Stack(children: [
        UserPhot(true),
        Positioned(
            child: Container(
              child: Icon(AppIcon.pencil_edit_button1111111,size: SizeConfig.safeBlockVertical*2,),
              decoration: BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
              ),
              width: SizeConfig.blockSizeVertical * 4,
              height: SizeConfig.blockSizeVertical * 4,
            ),
            bottom: 0,
            right: 0,
        )
      ]),
      SizedBox(height: SizeConfig.blockSizeVertical*4),
      Content(),
      SizedBox(height: SizeConfig.blockSizeVertical*2),
      SocialAccountItem(title: "Instagram"),
      SizedBox(height: SizeConfig.blockSizeVertical*2),
      SocialAccountItem(title: "Facebook"),
      SizedBox(height: SizeConfig.blockSizeVertical*2),
      SocialAccountItem(title: "Youtube"),
      SizedBox(height: SizeConfig.blockSizeVertical*2),
              ],
            ),
          ),
          height: SizeConfig.screenHeight,
          padding: EdgeInsets.only(
      // bottom:
      //     SizeConfig.screenHeight - (SizeConfig.safeBlockVertical * 100),
      ),
          width: SizeConfig.screenWidth,
          decoration: BoxDecoration(
            gradient: LinearGradient(
      colors: [Color(0xFF77382C), Theme.of(context).primaryColor],
      begin: Alignment.bottomCenter,
      end: Alignment.topCenter,
            ),
          ),
        ),
      resizeToAvoidBottomInset: false,
      //backgroundColor: Color(0xFFE9E9E9)
    );
  }
}
