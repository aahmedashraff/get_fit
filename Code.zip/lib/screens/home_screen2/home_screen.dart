import 'package:CaptainSayedApp/models/program_model.dart';
import 'package:CaptainSayedApp/repos/repos_fun.dart';
import 'package:CaptainSayedApp/screens/home_Screen/screen_widgets/bottom_navigation_bar.dart';
import 'package:CaptainSayedApp/screens/home_screen2/search_screen.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/articles.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/before_and_after.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/body_build_sec.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/calis_sec.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/category_item.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/drawer_icon.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/my_drawer.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/premium_programs.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/routines.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/search_bar.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/soon_text.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/weight_lose_sec.dart';
import 'package:CaptainSayedApp/screens/home_screen2/widgets/welcome_sec.dart';
import 'package:CaptainSayedApp/screens/view_all_screen/view_all_recommended.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class HomeScreen extends StatelessWidget {
  final GlobalKey<ScaffoldState> _drawerKey = GlobalKey();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // resizeToAvoidBottomInset: false,
      key: _drawerKey,
      drawer: Theme(
          data: Theme.of(context).copyWith(canvasColor: Color(0xFFE9E9E9)),
          child: Drawer(
            child: MyDrawer(),
          )),
      body: ListView(
        children: [
          DrawerIcon(() => _drawerKey.currentState.openDrawer()),
          Stack(children: [
            Hero(
              tag: "ss",
              child: SearchBar(isComingFromSearchScreen: false,),
            ),
            Positioned.fill(
              child: GestureDetector(
              child:Container(decoration: BoxDecoration(color: Colors.transparent)),
              onTap: () {
                  Navigator.push(
                      context, MaterialPageRoute(builder: (_) => SearchScreen()));
                },
          ),
            )
          ],),
          SizedBox(height: SizeConfig.safeBlockVertical),
          Stack(children: [
            WelcomeSec(),
            Positioned.fill(
              child: GestureDetector(
                child: Container(
                  color: Colors.transparent,
                ),
                onTap: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (_) => ViewRecommendedProgramsScreen()));
                },
              ),
            ),
          ]),
          SizedBox(height: SizeConfig.safeBlockVertical * 3),
          FutureBuilder<Map<String, List<ProgramModel>>>(
            future: getCategories(),
            builder: (_, snap) {
              if (snap.connectionState == ConnectionState.waiting ||
                  snap.hasError)
                return Padding(
                  padding:
                      EdgeInsets.only(bottom: SizeConfig.safeBlockVertical * 3),
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                );
              return Column(
                children: snap.data.keys
                    .map((programName) => CategoryItem(
                          categoryName: programName,
                          allPrograms: snap.data[programName],
                        ))
                    .toList(),
              );
            },
          ),
          // CalisSec(),
          // SizedBox(height: SizeConfig.safeBlockVertical * 3),
          // BodyBuildSec(),
          // SizedBox(height: SizeConfig.safeBlockVertical * 3),
          // WeightLoseSec(),
          // SizedBox(height: SizeConfig.safeBlockVertical * 3),
          Routines(),
          SizedBox(height: SizeConfig.safeBlockVertical * 3.5),
          Articles(),
          SizedBox(height: SizeConfig.safeBlockVertical * 3.5),
          BeforeAndAfter(),
          SizedBox(height: SizeConfig.safeBlockVertical * 3.5),
          PremuimPrograms(),
          SizedBox(height: MediaQuery.of(context).viewInsets.bottom / 2)
        ],
        // padding: EdgeInsets.symmetric(
        //   vertical: SizeConfig.safeBlockVertical,
        // ),
      ),
      bottomNavigationBar: SizedBox(
        child: BottomNavigationToolBar(),
        // height: SizeConfig.safeBlockVertical * 6,
        height: 56,
      ),
      backgroundColor: Color(0xFFE9E9E9),
    );
  }
}
