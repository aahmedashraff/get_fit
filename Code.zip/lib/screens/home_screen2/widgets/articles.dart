import 'package:CaptainSayedApp/screens/home_screen2/widgets/small_image.dart';
import 'package:CaptainSayedApp/screens/view_all_screen/all_articles.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

class Articles extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding:
          EdgeInsets.symmetric(horizontal: SizeConfig.safeBlockHorizontal * 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                "Articles",
                style: TextStyle(
                  fontSize: SizeConfig.safeBlockHorizontal * 4,
                  fontWeight: FontWeight.bold,
                ),
              ),
              Spacer(),
              InkWell(
                child: Text(
                  "View All",
                  style: TextStyle(
                    fontSize: SizeConfig.safeBlockHorizontal * 3,
                  ),
                ),
                onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => AllArticles(),
                )),
              ),
            ],
          ),
          SizedBox(height: SizeConfig.safeBlockVertical),
          Container(
            child: GestureDetector(
              child: ClipRRect(
                child: Image.asset(
                  "assets/images/Fat.jpg",
                  width: double.infinity,
                  height: SizeConfig.safeBlockVertical * 25,
                  fit: BoxFit.cover,
                ),
                borderRadius:
                    BorderRadius.circular(SizeConfig.safeBlockHorizontal),
              ),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                builder: (_) => AllArticles(),
              )),
            ),
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(.5),
                  blurRadius: 4,
                  // spreadRadius: 0,
                  offset: Offset(0, SizeConfig.safeBlockVertical * .25),
                )
              ],
              //border: Border.all(color: Theme.of(context).primaryColor),
              borderRadius:
                  BorderRadius.circular(SizeConfig.safeBlockHorizontal),
            ),
          ),
          SizedBox(height: SizeConfig.safeBlockVertical * 3),
        ],
      ),
    );

    // return Column(

    //   children: [
    //     Padding(
    //       padding: EdgeInsets.symmetric(
    //           horizontal: SizeConfig.safeBlockHorizontal * 4),
    //       child: Row(
    //         children: [
    //           Text(
    //             "Articles",
    //             style: TextStyle(
    //               fontSize: SizeConfig.safeBlockHorizontal * 4,
    //               fontWeight: FontWeight.bold,
    //             ),
    //           ),
    //           Spacer(),
    //           Text(
    //             "View All",
    //             style: TextStyle(
    //               fontSize: SizeConfig.safeBlockHorizontal * 3,
    //             ),
    //           )
    //         ],
    //       ),
    //     ),
    //     SizedBox(height: SizeConfig.safeBlockVertical),
    //     Container(
    //       height: SizeConfig.safeBlockVertical * 21,
    //       child: ListView(
    //         children: [
    //           for (var i = 2; i < 8; i = i + 2)
    //             Row(
    //               children: [
    //                 Column(
    //                   children: [
    //                     SmallImage(),
    //                     SizedBox(height: SizeConfig.safeBlockVertical),
    //                     Text(
    //                       i == 2 ? "How To Bang" : "Fights In Streets",
    //                       style: TextStyle(
    //                         height: 1,
    //                         fontSize: SizeConfig.safeBlockVertical * 1.45,
    //                       ),
    //                     )
    //                   ],
    //                   crossAxisAlignment: CrossAxisAlignment.start,
    //                 ),
    //                 SizedBox(
    //                     width: i == 8 ? 0 : SizeConfig.safeBlockHorizontal * 2)
    //               ],
    //             ),
    //         ],
    //         scrollDirection: Axis.horizontal,
    //         padding: EdgeInsets.symmetric(vertical: 0,
    //             horizontal: SizeConfig.safeBlockHorizontal * 4),
    //       ),
    //     )
    //   ],
    //   crossAxisAlignment: CrossAxisAlignment.start,
    // );
  }
}
