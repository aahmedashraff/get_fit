import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RadioButtonContainer extends StatelessWidget {
  final String title;
  final String subtitle;
  final bool isFromLevelScreen;
  RadioButtonContainer({
    @required this.subtitle,
    @required this.title,
    this.isFromLevelScreen,
  });
  @override
  Widget build(BuildContext context) {
    final userData = Provider.of<UserData>(context);
    return GestureDetector(
      onTap: () {
        isFromLevelScreen
            ? userData.selectUserLevel(title)
            : userData.selectUserGoal(title);
      },
      child: Container(
        constraints: BoxConstraints(
          minHeight: SizeConfig.safeBlockVertical * 12,
        ),
        padding: EdgeInsets.symmetric(
            horizontal: SizeConfig.safeBlockVertical * 1.2,
            vertical: SizeConfig.safeBlockVertical),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: Theme.of(context).textTheme.headline2.copyWith(
                        fontSize: SizeConfig.safeBlockHorizontal * 4.5),
                    textAlign: TextAlign.right,
                  ),
                  SizedBox(height: SizeConfig.safeBlockVertical * 1.2),
                  LayoutBuilder(
                    builder: (_, con) => SizedBox(
                      width: check(userData)
                          ? con.maxWidth * .85
                          : con.maxWidth * .77,
                      child: Text(
                        subtitle,
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: SizeConfig.safeBlockHorizontal * 3.5,
                        ),
                      ),
                    ),
                  )
                ],
              ),
            ),
            if (check(userData))
              Container(
                child: Icon(
                  AppIcon.check,
                  color: Colors.white,
                ),
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Theme.of(context).primaryColor,
                ),
                padding: EdgeInsets.all(SizeConfig.safeBlockVertical),
              ),
          ],
        ),
        decoration: BoxDecoration(
          borderRadius:
              BorderRadius.circular(SizeConfig.safeBlockHorizontal * 2),
          border: Border.all(
            color:
                check(userData) ? Theme.of(context).primaryColor : Colors.white,
          ),
        ),
      ),
    );
  }

  bool check(UserData userData) {
    if (isFromLevelScreen) {
      return userData.getUserLevel == title;
    }
    return userData.getUserGoal == title;
  }
}
