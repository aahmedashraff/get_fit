import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CreateTextInput extends StatefulWidget {
  final String label;
  final bool isPassword;
  final bool showViewPasswordIcon;
  final bool isSubmitButtonClicked;
  final void Function(String value) updateStreamFunction;
  final AsyncSnapshot<String> snapShot;
  CreateTextInput({
    @required this.label,
    @required this.snapShot,
    @required this.isSubmitButtonClicked,
    @required this.updateStreamFunction,
    this.showViewPasswordIcon = false,
    this.isPassword = false,
  });
  @override
  _CreateTextInputState createState() => _CreateTextInputState();
}

class _CreateTextInputState extends State<CreateTextInput>
    with WidgetsBindingObserver {
  //all that lines from initState till dispose are to unfocus the text field
  // when soft keyboard is hidden when back is pressed
  
  // @override
  // void initState() {
  //   super.initState();
  //   WidgetsBinding.instance.addObserver(this);
  // }

  // @override
  // void didChangeMetrics() {
  //   super.didChangeMetrics();
  //   final value = WidgetsBinding.instance.window.viewInsets.bottom;
  //   if (value == 0) {
  //     FocusScope.of(context).unfocus();
  //   }
  // }

  // @override
  // void dispose() {
  //   super.dispose();
  //   WidgetsBinding.instance.removeObserver(this);
  // }

  var _showPass = false;
  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      TextFormField(
        style: TextStyle(color: Colors.white),
        cursorColor: Theme.of(context).primaryColor,
        decoration: InputDecoration(
          errorText:
              widget.isSubmitButtonClicked ? widget.snapShot.error : null,
          enabledBorder: UnderlineInputBorder(
            borderSide: BorderSide(color: Theme.of(context).primaryColor),
          ),
          labelText: widget.label,
          labelStyle: TextStyle(
            height: 1.5,
            color: Colors.white,
          ),
        ),
        keyboardType: widget.label == "Email"
            ? TextInputType.emailAddress
            : TextInputType.text,
        obscureText: widget.isPassword && !_showPass ? true : false,
        onChanged: (value) {
          
          widget.updateStreamFunction(value);
          if (widget.label == "Full name")
            Provider.of<UserData>(context,listen: false).updateFullName(value);
        },
      ),
      if (widget.showViewPasswordIcon)
        Positioned(
          top: widget.snapShot.hasError && widget.isSubmitButtonClicked
              ? 0
              : null,
          right: 0,
          bottom: !widget.snapShot.hasError || !widget.isSubmitButtonClicked
              ? 0
              : null,
          child: IconButton(
            icon: Icon(
              _showPass ? Icons.visibility : Icons.visibility_off,
              color: Colors.white,
            ),
            onPressed: () {
              setState(() {
                _showPass = !_showPass;
              });
            },
          ),
        ),
    ]);
  }
}
