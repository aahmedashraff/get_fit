import 'dart:ui';
import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/providers/bloc/bloc.dart';
import 'package:CaptainSayedApp/screens/login_screen.dart';
import 'package:CaptainSayedApp/screens/sign_up_screen.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LayoutOfAllFirstScreens extends StatelessWidget {
  static const screenName = "/layout-of-all-first-screens";

  final Widget cloumnOfData;
  LayoutOfAllFirstScreens(this.cloumnOfData);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          children: [
            Image.asset(
              "assets/images/1.jpg",
              width: SizeConfig.screenWidth,
              height: SizeConfig.screenHeight,
              fit: BoxFit.cover,
            ),
            Positioned.fill(
              child: BackdropFilter(
                filter: ImageFilter.blur(
                  sigmaX: 25.0,
                  sigmaY: 25.0,
                ),
                child: Container(color: Colors.black.withOpacity(.1)),
              ),
            ),
            Container(
              // decoration: BoxDecoration(
              //   border: Border.all(width: 3, color: Colors.white),
              // ),
              width: SizeConfig.screenWidth,
              height: SizeConfig.screenHeight,
              child: cloumnOfData,
              margin: EdgeInsets.symmetric(
                vertical: MediaQuery.of(context).padding.top,
                horizontal: SizeConfig.safeBlockHorizontal * 7,
              ),
            ),
            Positioned(
              child: IconButton(
                color: Theme.of(context).primaryColor,
                icon: Icon(AppIcon.back),
                onPressed: () {
                   //those next tow lines is to avoid an error which is occured
                  // when pressing navigate.pop from this page and the
                  //keyboard is visible. the previous page is get out of bound
                  // for a moment
                  Future.delayed(Duration(milliseconds: 150))
                      .then((_) => Navigator.of(context).pop());
                  FocusScope.of(context).unfocus();
                  
                  
                },
              ),
              left: SizeConfig.safeBlockHorizontal * 4,
              top: SizeConfig.safeBlockVertical * 4,
            ),
          ],
        ),
        width: SizeConfig.screenWidth,
        height: SizeConfig.screenHeight,
      ),
    );
  }
}
