import 'package:CaptainSayedApp/app_icon_icons.dart';
import 'package:CaptainSayedApp/providers/user_data.dart';
import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class CreateGenderBox extends StatelessWidget {
  const CreateGenderBox({
    Key key,
    @required this.male,
  }) : super(key: key);

  final bool male;

  @override
  Widget build(BuildContext context) {
    final userData = Provider.of<UserData>(context);
    return GestureDetector(
      onTap: () => (male && userData.userGender == "Male") ||
              (!male && userData.userGender != "Male")
          ? null
          : userData.selectGender(),
      child: Container(
        constraints: BoxConstraints(
          minWidth: SizeConfig.safeBlockHorizontal * 43,
          minHeight: SizeConfig.safeBlockVertical * 20,
        ),
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.safeBlockVertical * 1.2,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Icon(
              male ? AppIcon.male : AppIcon.female,
              size: (SizeConfig.safeBlockHorizontal +
                      SizeConfig.safeBlockVertical) /
                  2 *
                  12,
              color: Colors.white,
            ),
            Text(
              male ? "Male" : "Female",
              style: Theme.of(context)
                  .textTheme
                  .headline2
                  .copyWith(fontSize: SizeConfig.safeBlockHorizontal * 6),
            )
          ],
        ),
        decoration: BoxDecoration(
          borderRadius:
              BorderRadius.circular(SizeConfig.safeBlockHorizontal * 3),
          border: Border.all(
            color: (male && userData.userGender == "Male") ||
                    (!male && userData.userGender != "Male")
                ? Theme.of(context).primaryColor
                : Colors.white,
            width: SizeConfig.safeBlockHorizontal,
          ),
        ),
      ),
    );
  }
}
