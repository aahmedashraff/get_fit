import 'package:CaptainSayedApp/sizeConfig.dart';
import 'package:flutter/material.dart';

//this is for the button at the end of the all first screens
class NextOrSubmitButton extends StatelessWidget {
  final String text;
  final Function onPress;
  NextOrSubmitButton(this.text,{this.onPress});
  @override
  Widget build(BuildContext context) {
    return GestureDetector(onTap: onPress,
          child: Container(
        child: Text(
          text,
          style: TextStyle(
            color: Colors.black,
            fontWeight: FontWeight.bold,
            fontSize: SizeConfig.blockSizeVertical * 2,
          ),
        ),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(
            SizeConfig.safeBlockHorizontal * 2,
          ),
          color: Theme.of(context).primaryColor,
        ),
        padding: EdgeInsets.symmetric(
          vertical: SizeConfig.safeBlockVertical * 1.65,
        ),
        width: double.infinity,
        alignment: Alignment.center,
      ),
    );
  }
}
